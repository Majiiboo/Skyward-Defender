extends Control
# Home Hub, container rebuild (dev27, Gemini structure, adapted).
# Root Full Rect, MarginContainer 12px safe margins, MainVBox flow:
# Top, Stage, AFKSpacer (expands, pushes bottom to bottom),
# AFKLabel, BestLabel, ActionRow HBox, NavRow HBox (equal width).
# Side icons are LeftVBox/RightVBox (container stacking, not absolute
# per-button y). AFK hero is a live game object, not UI, so it stays
# as a dynamic layer (AFKDraw + Hero), not inside the VBox.
# Theme = MenuStyle (shared StyleBoxFlat, our reusable .theme
# equivalent). Entry animation: MainVBox fades in + slides up on load.
# Clean code connections, like Gemini's main_menu.gd example:
# Play = Battle, Gear, Modes, Quests, Store.

@onready var hero: TextureRect = $Hero
var hero_base_y := 0.0
var t := 0.0
var stage := 1
var mode := "Normal"
var elite_unlocked := false

func _ready() -> void:
	size = get_viewport_rect().size
	$Background.size = size
	# Dev41 seamless dock (Gemini, adapted): bar is flush with the
	# bottom edge (margin 0, not 12), so the dock meets the screen
	# edge instead of floating above it. Top/left/right safe margins kept.
	$Margin.add_theme_constant_override("margin_bottom", 0)
	for _n in [self, $Margin, $Margin/MainVBox, $Margin/MainVBox/NavBar, $Margin/MainVBox/NavBar/NavVBox, $Margin/MainVBox/NavBar/NavVBox/NavRow]:
		_n.clip_contents = false
	_fade_in_overlay()
	# Safe area is now owned by safe_area_margin.gd on the Margin
	# node (Gemini script, reusable, re-checks on size change).
	# Margin _ready runs before Hub _ready, so read its result here.
	var _bottom_pad: int = $Margin.get_theme_constant("margin_bottom")
	MenuAnim.pop_buttons(self)
	# Gemini Part 1: Theme cascades from root, no per-button styleboxes.
	var th := load("res://game_theme.tres")
	if th: theme = th
	# Icon pack (dev32): buttons are icon-only, no wording. Assign by
	# node name, not by text (text is now empty, so text-based mapping
	# would find nothing). 64px pack icons, consistent cyan/purple/gold.
	var _pack = {
		"NavStore": "nav_store", "NavGear": "nav_gear", "NavBattle": "nav_battle",
		"NavModes": "nav_modes", "NavQuests": "nav_quests",
		"ChestButton": "pack_chest", "PatrolButton": "pack_patrol",
		"BattleButton": "pack_battle",
		"EventButton": "pack_event", "PromoButton": "pack_promo", "StarterButton": "pack_starter",
		"DailyButton": "pack_daily", "GiftsButton": "pack_gifts", "RanksButton": "pack_ranks",
	}
	# Dull/active (dev34): only the active tab is lit. On Home that's
	# Battle. Every other nav tab starts dull, single-colour, with no
	# filled visor / gold swords / filled middle tier.
	var _dull = {"NavStore": "nav_store_dull", "NavGear": "nav_gear_dull", "NavBattle": "nav_battle_dull", "NavModes": "nav_modes_dull", "NavQuests": "nav_quests_dull"}
	for _node in [$Margin/MainVBox/NavBar/NavVBox/NavRow/SlotStore/NavStore, $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotGear/NavGear, $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotBattle/NavBattle, $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotModes/NavModes, $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotQuests/NavQuests, $Margin/MainVBox/ActionRow/ChestButton, $Margin/MainVBox/ActionRow/PatrolButton, $Margin/MainVBox/ActionRow/BattleButton, $LeftVBox/EventButton, $LeftVBox/PromoButton, $LeftVBox/StarterButton, $RightVBox/DailyButton, $RightVBox/GiftsButton, $RightVBox/RanksButton]:
		var _key = _pack[_node.name]
		if _node.name in _dull and _node.name != "NavBattle":
			_key = _dull[_node.name]
		var _tex = load("res://icons/%s.png" % _key)
		if _tex: _node.icon = _tex
	# Hero centred in AFK area: between stage header (~200) and bottom
	# rows (~size.y-180). AFKSpacer in the VBox is what creates that
	# area, so hero follows the same math, not a fixed y.
	var action_y := size.y - 180.0 - float(_bottom_pad - 12)
	var hero_y := (200.0 + action_y) / 2.0 - 67.0
	hero.position = Vector2(size.x / 2.0 - 35.0, hero_y)
	hero_base_y = hero_y
	var coins := 0
	var best_score := 0
	var best_kills := 0
	if FileAccess.file_exists("user://skybound_save.json"):
		var f := FileAccess.open("user://skybound_save.json", FileAccess.READ)
		if f:
			var data = JSON.parse_string(f.get_as_text())
			if typeof(data) == TYPE_DICTIONARY:
				coins = int(data.get("coins", 0))
				best_score = int(data.get("best_score", 0))
				best_kills = int(data.get("best_kills", 0))
	$Margin/MainVBox/TopBar/LVLabel.text = "1"
	$Margin/MainVBox/TopBar/CoinLabel.text = "%d" % coins
	$Margin/MainVBox/TopBar/PartsLabel.text = "0"
	# Two lines, not one 70-char line — a single long label forced the
	# whole VBox wider than the screen in dev27, pushing Nav/Patrol/
	# right-side buttons off the right edge.
	$Margin/MainVBox/BestLabel.text = "BEST RUN: Score %d  •  Kills %d\nEQUIPPED: Single Rifle, Charcoal Plate" % [best_score, best_kills]
	_update_stage_label()
	_hide_panels()
	# Entry animation: fade in only. dev46: the old slide-up tween on
	# MainVBox.position.y broke Margin layout - it tweened from the
	# pre-layout position (0), so MainVBox stayed at y=0 instead of
	# the margin position, and the container never re-sorted it until
	# the first menu tap (visibility change) forced a layout pass.
	# That is why Home's bar sat high on first open and dropped on
	# the first menu tap, every launch. Fade does not move layout.
	var main_vbox: Control = $Margin/MainVBox
	main_vbox.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(main_vbox, "modulate:a", 1.0, 0.4)
	# Clean button connections.
	$Margin/MainVBox/ActionRow/BattleButton.pressed.connect(func(): _smooth_change_scene("res://battle.tscn"))
	$Margin/MainVBox/StageVBox/ModeRow/NormalButton.pressed.connect(func(): _set_mode("Normal"))
	$Margin/MainVBox/StageVBox/ModeRow/EliteButton.pressed.connect(func(): _set_mode("Elite"))
	$Margin/MainVBox/StageVBox/StageRow/PrevButton.pressed.connect(func(): _change_stage(-1))
	$Margin/MainVBox/StageVBox/StageRow/NextButton.pressed.connect(func(): _change_stage(1))
	$Margin/MainVBox/StageVBox/StageRow/StageLabelButton.pressed.connect(func(): _show_panel($SelectPanel))
	$Margin/MainVBox/ActionRow/ChestButton.pressed.connect(func(): _show_panel($InfoPanel))
	$Margin/MainVBox/ActionRow/PatrolButton.pressed.connect(func(): _show_panel($PatrolPanel))
	$LeftVBox/EventButton.pressed.connect(func(): _side_popup("EVENT", "Seasonal event — coming soon.\nThis side slot is for events\nand promotions."))
	$LeftVBox/PromoButton.pressed.connect(func(): _side_popup("PROMO", "Special deal — coming soon.\nThis side slot is for deals\nand bundles."))
	$LeftVBox/StarterButton.pressed.connect(func(): _side_popup("STARTER", "Starter pack — test only.\nSimple card, no purchase yet."))
	$RightVBox/DailyButton.pressed.connect(func(): _side_popup("DAILY", "Daily check-in — coming soon.\nClaim will be here."))
	$RightVBox/GiftsButton.pressed.connect(func(): _side_popup("GIFTS", "Gifts — coming soon.\nClaimable gifts will list here."))
	$RightVBox/RanksButton.pressed.connect(func(): _side_popup("RANKS", "Rankings — coming soon.\nLeaderboard will list here."))
	$SelectPanel/SelectClose.pressed.connect(func(): _hide_panels())
	$SelectPanel/SelectGo.pressed.connect(func(): _smooth_change_scene("res://battle.tscn"))
	$PatrolPanel/PatrolClose.pressed.connect(func(): _hide_panels())
	$PatrolPanel/PatrolClaim.pressed.connect(func(): $PatrolPanel/PatrolLabel.text = "Auto-Patrol Gain\nCoins 34/h, Parts 8/h\nClaim will give 612 coins, 18 parts, 144 gems (show-only).\nNo granting yet — battle rewards update enables it.")
	$InfoPanel/InfoClose.pressed.connect(func(): _hide_panels())
	$SidePanel/SideClose.pressed.connect(func(): _hide_panels())
	# Unified inactive set (dev42): ALL inactive tabs use their dull
	# slate texture, modulate white. No dimmed-lit Store/Quests, which
	# stayed cyan/gold and looked brighter than the grey Gear/Modes.
	$Margin/MainVBox/NavBar/NavVBox/NavRow/SlotStore/NavStore.pressed.connect(func(): _on_nav_tap("NavStore", "res://store.tscn"))
	$Margin/MainVBox/NavBar/NavVBox/NavRow/SlotGear/NavGear.pressed.connect(func(): _on_nav_tap("NavGear", "res://gear.tscn"))
	$Margin/MainVBox/NavBar/NavVBox/NavRow/SlotModes/NavModes.pressed.connect(func(): _on_nav_tap("NavModes", "res://modes.tscn"))
	$Margin/MainVBox/NavBar/NavVBox/NavRow/SlotQuests/NavQuests.pressed.connect(func(): _on_nav_tap("NavQuests", "res://quests.tscn"))
	$Margin/MainVBox/NavBar/NavVBox/NavRow/SlotBattle/NavBattle.pressed.connect(func(): _on_nav_tap("NavBattle", ""))
	# Nav state (dev34): single bar, no individual boxes, transparent
	# icons, active tab lifts into a notch with its word under it only.
	# NavBar PanelContainer is the single bar background.
	var _bar = StyleBoxFlat.new()
	# dev46: bar bg more transparent (0.85 -> 0.70) so the background
	# behind the dock shows through a little, per Rudy.
	_bar.bg_color = Color(0.043, 0.059, 0.098, 0.70)
	_bar.border_color = Color(0, 0.898, 1.0)
	_bar.border_width_left = 0; _bar.border_width_right = 0; _bar.border_width_top = 2; _bar.border_width_bottom = 0
	_bar.corner_radius_top_left = 20; _bar.corner_radius_top_right = 20; _bar.corner_radius_bottom_left = 0; _bar.corner_radius_bottom_right = 0
	_bar.content_margin_top = 12; _bar.content_margin_bottom = 8; _bar.content_margin_left = 8; _bar.content_margin_right = 8
	# dev44 dock pop, dialled back dev46 per Rudy: shadow smaller and
	# fainter (16 -> 10, alpha 0.35 -> 0.22). Shadow offset up
	# (negative y) so the glow sits over the menu area, not off the
	# bottom edge of the screen.
	_bar.shadow_color = Color(0, 0.898, 1.0, 0.22)
	_bar.shadow_size = 10
	_bar.shadow_offset = Vector2(0, -6)
	$Margin/MainVBox/NavBar.add_theme_stylebox_override("panel", _bar)
	# Dev42: label closer to lifted icon. NavVBox separation 2 -> -10,
	# so label row overlaps NavRow bottom by 10px: lifted icon bottom
	# is at slot bottom -12, label top is then 2px below icon bottom
	# instead of 14px below (2 separation + 12 lift gap).
	$Margin/MainVBox/NavBar/NavVBox.add_theme_constant_override("separation", -10)
	# Flat transparent buttons: no per-button box, bar is the background.
	var _empty = StyleBoxEmpty.new()
	_nav_empty = _empty
	# dev44 active-tab glow: StyleBox shadow draws behind the icon
	# (icon is button content, drawn after the stylebox), so the halo
	# pops around the active icon without covering it.
	_nav_glow = StyleBoxFlat.new()
	_nav_glow.bg_color = Color(0, 0, 0, 0)
	_nav_glow.border_width_left = 0; _nav_glow.border_width_right = 0; _nav_glow.border_width_top = 0; _nav_glow.border_width_bottom = 0
	_nav_glow.corner_radius_top_left = 36; _nav_glow.corner_radius_top_right = 36; _nav_glow.corner_radius_bottom_left = 36; _nav_glow.corner_radius_bottom_right = 36
	_nav_glow.shadow_color = Color(0, 0.898, 1.0, 0.5)
	_nav_glow.shadow_size = 14
	_nav_glow.shadow_offset = Vector2(0, 0)
	for _b in [$Margin/MainVBox/NavBar/NavVBox/NavRow/SlotStore/NavStore, $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotGear/NavGear, $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotBattle/NavBattle, $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotModes/NavModes, $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotQuests/NavQuests]:
		_b.add_theme_stylebox_override("normal", _empty)
		_b.add_theme_stylebox_override("hover", _empty)
		_b.add_theme_stylebox_override("pressed", _empty)
		_b.add_theme_stylebox_override("focus", _empty)
		# dev44 bold icons: nav files are now 288px, not 72px. With
		# expand_icon the button stays 72x72 (its custom minimum) and
		# the icon scales down to fit, instead of the 288px texture
		# blowing the whole nav row up. Verified headless: expand on
		# drops a 1600px icon's minimum from 1608 to 8, so the 72px
		# custom minimum governs.
		_b.expand_icon = true
	# Active-only label: Battle only on Home, others blank (already "" in tscn).
	var _lbl = $Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelBattle
	_lbl.add_theme_color_override("font_color", Color(1, 0.8, 0.3))
	for _l in [$Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelStore, $Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelGear, $Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelModes, $Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelQuests]:
		_l.add_theme_font_size_override("font_size", 14)
	_lbl.add_theme_font_size_override("font_size", 14)
	_lbl.modulate.a = 0.0
	# View Manager (dev43): persistent Hub shell. ViewContainer holds
	# Gear/Modes/Quests/Store views; NavBar stays in MainVBox above it
	# (tree order after Background, z 0), so nav + notch + lit tab persist on every
	# menu. Battle stays a separate game scene, not a view.
	_view_container = Control.new()
	_view_container.name = "ViewContainer"
	_view_container.clip_contents = true
	# dev44 fix: was -10, which drew the view BEHIND Hub's opaque
	# full-screen Background (z 0) on the phone, so every menu looked
	# empty. z 0 + tree order after Background (move_child 3, before
	# Margin) puts the view above Background but below Margin/NavBar.
	_view_container.z_index = 0
	_view_container.size = size
	add_child(_view_container)
	move_child(_view_container, 3)
	# Notch + lift + label fade, smooth (Tween, not instant jump).
	# Deferred so containers have laid out first, then animate in.
	call_deferred("_animate_nav_in")

var _transitioning := false
var _nav_notch: Panel = null
var _nav_border_cover: ColorRect = null
var _nav_glow: StyleBoxFlat = null
var _nav_empty: StyleBoxEmpty = null
var _nav_base_y := {}
var _nav_active := "NavBattle"
var _nav_lift := {}
var _nav_scale := {}
var _nav_base_captured := false
var _pulse_tween: Tween = null
var _view_container: Control = null
var _current_view: Control = null
var _current_view_name := "NavBattle"

func _on_nav_tap(tapped: String, path: String) -> void:
	if _transitioning: return
	_transitioning = true
	_stop_nav_pulse()
	# Light up tapped, dull previous (Battle on Home).
	var _lit = {"NavStore": "nav_store", "NavGear": "nav_gear", "NavBattle": "nav_battle", "NavModes": "nav_modes", "NavQuests": "nav_quests"}
	var _dull2 = {"NavStore": "nav_store_dull", "NavGear": "nav_gear_dull", "NavBattle": "nav_battle_dull", "NavModes": "nav_modes_dull", "NavQuests": "nav_quests_dull"}
	var _btns = {"NavStore": $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotStore/NavStore, "NavGear": $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotGear/NavGear, "NavBattle": $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotBattle/NavBattle, "NavModes": $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotModes/NavModes, "NavQuests": $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotQuests/NavQuests}
	var _lbls = {"NavStore": $Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelStore, "NavGear": $Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelGear, "NavBattle": $Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelBattle, "NavModes": $Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelModes, "NavQuests": $Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelQuests}
	for _k in _btns.keys():
		var _tex = load("res://icons/%s.png" % (_lit[_k] if _k == tapped else _dull2[_k]))
		if _tex: _btns[_k].icon = _tex
		_btns[_k].modulate = Color(1, 1, 1, 1)
		_lbls[_k].text = _k.substr(3).to_upper() if _k == tapped else ""
		if _k == tapped: _lbls[_k].add_theme_color_override("font_color", Color(1, 0.8, 0.3))
		# dev45: active-icon glow REMOVED per Rudy (dev44 phone test:
		# it rendered as a big teal disc behind the icon, not a halo).
		# All buttons stay flat/empty; the dock's own glow stays.
		if _nav_empty != null:
			_btns[_k].add_theme_stylebox_override("normal", _nav_empty)
			_btns[_k].add_theme_stylebox_override("hover", _nav_empty)
			_btns[_k].add_theme_stylebox_override("pressed", _nav_empty)
			_btns[_k].add_theme_stylebox_override("focus", _nav_empty)
	_nav_active = tapped
	_spawn_spark_burst(_btns[tapped])
	# Gemini wrapper + notch batches, proper Tween (not per-frame hack):
	# each button lives inside its own Control slot, so HBox cannot snap
	# its position back. One parallel Tween glides: button position.y
	# (inside its slot), button scale, button fade-in, label fade, and
	# notch position.x (notch is a Hub sibling outside NavRow, so it
	# glides freely across the whole bar width).
	var tw := create_tween()
	tw.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	for _k in _btns.keys():
		var _b = _btns[_k]
		_b.pivot_offset = _b.size / 2.0
		var _ty = -12.0 if _k == tapped else 0.0
		var _ts = 1.08 if _k == tapped else 1.0
		tw.parallel().tween_property(_b, "position:y", _ty, 0.35)
		tw.parallel().tween_property(_b, "scale", Vector2(_ts, _ts), 0.35)
		if _k == tapped:
			_b.modulate.a = 0.4
			tw.parallel().tween_property(_b, "modulate:a", 1.0, 0.35)
	if _nav_notch != null:
		# dev53, drawn asset swap (Rudy: try the asset way,
		# code notches clearly were not working). Three
		# textures, same shape idea as dev52's code shapes,
		# but baked into the image so the curve is exactly
		# as drawn, not dependent on StyleBox radius
		# clamping/layout: middle = notch_middle.png
		# (92x12), left edge = notch_left.png (92x32,
		# outer curve 20, dock-apparent fill, bottom
		# reaches bar_top+20 covering the dock's own
		# corner arc), right edge = notch_right.png
		# (mirror). Dock corners STAY 20/20 always.
		# Texture/size are set BEFORE _nx is calculated,
		# so edge->middle never goes off-centre (dev51 bug).
		var _bar_rect = $Margin/MainVBox/NavBar.get_global_rect()
		var _tr = _btns[tapped].get_global_rect()
		var _nx: float
		var _nsb2 = _nav_notch.get_theme_stylebox("panel") as StyleBoxTexture
		if tapped == "NavStore":
			if _nsb2 != null: _nsb2.texture = load("res://icons/notch_left.png")
			_nav_notch.size = Vector2(92.0, 32.0)
			_nx = _bar_rect.position.x
		elif tapped == "NavQuests":
			if _nsb2 != null: _nsb2.texture = load("res://icons/notch_right.png")
			_nav_notch.size = Vector2(92.0, 32.0)
			_nx = _bar_rect.position.x + _bar_rect.size.x - 92.0
		else:
			if _nsb2 != null: _nsb2.texture = load("res://icons/notch_middle.png")
			_nav_notch.size = Vector2(92.0, 12.0)
			_nx = _tr.position.x + _tr.size.x / 2.0 - 46.0
		if _nav_border_cover != null:
			_nav_border_cover.size = Vector2(92.0, 2.0)
		tw.parallel().tween_property(_nav_notch, "position:x", _nx, 0.35)
		# dev44 notch-line fix: the border cover glides with the notch,
		# hiding only the bar-border segment directly under it.
		if _nav_border_cover != null:
			tw.parallel().tween_property(_nav_border_cover, "position:x", _nx, 0.35)
	tw.parallel().tween_property(_lbls[tapped], "modulate:a", 1.0, 0.30)
	await tw.finished
	_transitioning = false
	if tapped == "NavBattle":
		_show_home()
		_start_nav_pulse("NavBattle")
	else:
		_show_view(tapped, path)
		_start_nav_pulse(tapped)

func _set_home_visible(visible: bool) -> void:
	# View Manager: Home content on/off, NavBar always stays. When a
	# view is shown, MainVBox alignment END pushes the lone visible
	# NavBar to the bottom (otherwise a VBox with only NavBar visible
	# would put it at the top). AFK is paused in view mode.
	var main = $Margin/MainVBox
	main.alignment = BoxContainer.ALIGNMENT_BEGIN if visible else BoxContainer.ALIGNMENT_END
	for n in [$Margin/MainVBox/TopBar, $Margin/MainVBox/StageVBox, $Margin/MainVBox/AFKSpacer, $Margin/MainVBox/AFKLabel, $Margin/MainVBox/BestLabel, $Margin/MainVBox/ActionRow]:
		n.visible = visible
	$Hero.visible = visible
	$AFKDraw.visible = visible
	$LeftVBox.visible = visible
	$RightVBox.visible = visible
	if visible:
		$AFKDraw.process_mode = Node.PROCESS_MODE_INHERIT
	else:
		_hide_panels()
		$AFKDraw.process_mode = Node.PROCESS_MODE_DISABLED

func _show_home() -> void:
	if _current_view != null:
		_current_view.queue_free()
		_current_view = null
	_current_view_name = "NavBattle"
	_set_home_visible(true)

func _show_view(view_name: String, path: String) -> void:
	if _current_view != null:
		_current_view.queue_free()
		_current_view = null
	var view = load(path).instantiate()
	_current_view = view
	_current_view_name = view_name
	_view_container.add_child(view)
	# Back button: views were built standalone, so their Back handler
	# reloads Hub via change_scene_to_file. Inside View Manager that
	# would lose the persistent nav, so disconnect it here (views
	# themselves are NOT edited, standalone behaviour unchanged) and
	# route Back through the nav tap to Home, which also re-lights
	# Battle, moves the notch, and restarts the pulse.
	var back = view.get_node_or_null("BackButton")
	if back != null:
		for conn in back.pressed.get_connections():
			back.pressed.disconnect(conn["callable"])
		back.pressed.connect(func(): _on_nav_tap("NavBattle", ""))
	_set_home_visible(false)

func _stop_nav_pulse() -> void:
	if _pulse_tween != null and _pulse_tween.is_valid():
		_pulse_tween.kill()
	_pulse_tween = null

func _start_nav_pulse(tab: String = "NavBattle") -> void:
	# Gemini pulse batch, adapted: scale breathing only (1.08 -> 1.11
	# -> 1.08, 2.0s loop, dev42 slower/smaller for a smooth breath
	# instead of a bounce), NOT modulate, so it cannot fight the
	# unified dull inactive set. Dev43: pulse follows the active tab
	# (Battle on Home, Gear/Store/etc. in their views), not just
	# Battle; _on_nav_tap kills it first so it cannot fight the
	# tap tween's scale, and _show_home/_show_view restart it.
	_stop_nav_pulse()
	var _btns_pulse = {"NavStore": $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotStore/NavStore, "NavGear": $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotGear/NavGear, "NavBattle": $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotBattle/NavBattle, "NavModes": $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotModes/NavModes, "NavQuests": $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotQuests/NavQuests}
	var _b = _btns_pulse[tab]
	_b.scale = Vector2(1.08, 1.08)
	_pulse_tween = create_tween()
	_pulse_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_pulse_tween.set_loops(1000)
	_pulse_tween.tween_property(_b, "scale", Vector2(1.11, 1.11), 1.0)
	_pulse_tween.tween_property(_b, "scale", Vector2(1.08, 1.08), 1.0)

func _spawn_spark_burst(btn: Button) -> void:
	# Gemini spark batch, adapted: code-only dot burst, not
	# GPUParticles2D (no spark texture in the project, and a particle
	# node would be cut off by the scene change anyway). Dev42:
	# bigger, faster, unmissable during the 0.35s lift — 12 dots at
	# 10px (was 6px), out 38-62px (was 26-40), fade 0.35s (was 0.45),
	# plus a central flash that expands and fades in 0.3s. Burst
	# z_index 20 sits above the fade overlay, so it stays visible
	# into the fade, until the scene change frees it.
	var _c = btn.get_global_rect().get_center()
	var burst = Control.new()
	burst.name = "SparkBurst"
	burst.position = _c
	burst.z_index = 20
	add_child(burst)
	var tw := create_tween()
	tw.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	var flash = ColorRect.new()
	flash.size = Vector2(24, 24)
	flash.position = Vector2(-12, -12)
	flash.color = Color(1, 1, 1, 1)
	burst.add_child(flash)
	tw.parallel().tween_property(flash, "size", Vector2(48, 48), 0.3)
	tw.parallel().tween_property(flash, "position", Vector2(-24, -24), 0.3)
	tw.parallel().tween_property(flash, "modulate:a", 0.0, 0.3)
	for i in 12:
		var dot = ColorRect.new()
		dot.size = Vector2(10, 10)
		dot.position = Vector2(-5, -5)
		dot.color = Color(0, 0.898, 1.0) if i % 2 == 0 else Color(1, 0.8, 0.3)
		burst.add_child(dot)
		var _ang = float(i) * 0.524 + 0.3
		var _dist = 38.0 + float(i % 4) * 8.0
		var _target = Vector2(cos(_ang), sin(_ang)) * _dist
		tw.parallel().tween_property(dot, "position", _target - Vector2(5, 5), 0.35)
		tw.parallel().tween_property(dot, "modulate:a", 0.0, 0.35)
	tw.tween_callback(func(): burst.queue_free())

func _smooth_change_scene(path: String) -> void:
	if _transitioning: return
	_transitioning = true
	# Fade WHOLE screen to black (overlay), not just MainVBox — fading
	# only MainVBox left Background/AFK/side icons visible, then the new
	# scene popped in, which looked like an overlay flash in dev34 video.
	var overlay = ColorRect.new()
	overlay.color = Color(0, 0, 0, 1)
	overlay.size = size
	overlay.modulate.a = 0.0
	add_child(overlay)
	var tw := create_tween()
	tw.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_property(overlay, "modulate:a", 1.0, 0.25)
	await tw.finished
	get_tree().change_scene_to_file(path)

func _animate_nav_in() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	var nav_battle = $Margin/MainVBox/NavBar/NavVBox/NavRow/SlotBattle/NavBattle
	var nav_bar = $Margin/MainVBox/NavBar
	# Notch, dev53: DRAWN ASSET, not code StyleBoxFlat.
	# Rudy asked to try the asset way after code notches
	# kept failing on the phone. Notch is a Panel with a
	# StyleBoxTexture (NOT a TextureRect: a TextureRect
	# clamps its size up to its texture size, so a 368px
	# texture would force a 368px notch - proven in a
	# headless test. A StyleBoxTexture stretches the
	# 4x-drawn image down to the panel's 92px size, sharp).
	# Texture = notch_middle.png at start, swapped in
	# _on_nav_tap to notch_left.png / notch_right.png
	# (92x32, blended corner shape baked into the image).
	var notch = Panel.new()
	notch.name = "NavNotch"
	_nav_notch = notch
	var nsb = StyleBoxTexture.new()
	nsb.texture = load("res://icons/notch_middle.png")
	notch.add_theme_stylebox_override("panel", nsb)
	var bw = nav_battle.size.x
	if bw <= 0: bw = 90.0
	notch.size = Vector2(92.0, 12.0)
	notch.z_index = 10
	var bar_rect = nav_bar.get_global_rect()
	var battle_rect = nav_battle.get_global_rect()
	var target_x = battle_rect.position.x + battle_rect.size.x / 2.0 - (bw + 20.0) / 2.0
	notch.position = Vector2(bar_rect.position.x + 12, bar_rect.position.y - 12.0)
	add_child(notch)
	# dev44 notch-line fix: do NOT remove the whole top border (that
	# is the dock's glow line). Cover only the 2px segment under the
	# notch, in the bar's apparent colour (bar bg 0.85 alpha over Hub
	# bg), so the notch joins the bar with no line between them while
	# the rest of the line stays. Cover z 5: above the bar (z 0),
	# below the notch (z 10).
	var cover = ColorRect.new()
	cover.name = "NavBorderCover"
	# dev46: matches the new bar bg (0.70 alpha over Hub bg
	# 0.02,0.04,0.12), so the covered segment still blends in.
	cover.color = Color(0.036, 0.053, 0.105, 1)
	cover.size = Vector2(notch.size.x, 2.0)
	cover.z_index = 5
	cover.position = Vector2(notch.position.x, bar_rect.position.y)
	_nav_border_cover = cover
	add_child(cover)
	_nav_active = "NavBattle"
	# Centre each button inside its slot (slot is a plain Control, so
	# this position sticks — HBox only positions the slots, not the
	# buttons inside them). Battle starts lifted + scaled, others centred.
	for _slot_name in ["SlotStore", "SlotGear", "SlotBattle", "SlotModes", "SlotQuests"]:
		var _slot = $Margin/MainVBox/NavBar/NavVBox/NavRow.get_node(_slot_name)
		var _btn = _slot.get_child(0)
		_btn.position.x = (_slot.size.x - _btn.size.x) / 2.0
		_btn.pivot_offset = _btn.size / 2.0
		if _slot_name == "SlotBattle":
			_btn.position.y = -12.0
			_btn.scale = Vector2(1.08, 1.08)
		else:
			_btn.position.y = 0.0
			_btn.scale = Vector2(1.0, 1.0)
	# Notch: Hub child, sibling outside NavRow (Gemini notch batch),
	# so it can glide across the whole bar, not inside a slot.
	notch.position = Vector2(battle_rect.position.x + battle_rect.size.x / 2.0 - notch.size.x / 2.0, bar_rect.position.y - 12.0)
	if _nav_border_cover != null:
		_nav_border_cover.position = Vector2(notch.position.x, bar_rect.position.y)
	# dev45: no active-icon glow on Battle either (see tap handler).
	var tw := create_tween()
	tw.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_property($Margin/MainVBox/NavBar/NavVBox/NavLabelRow/LabelBattle, "modulate:a", 1.0, 0.30)
	_start_nav_pulse()

func _process(delta: float) -> void:
	# dev45 first-load gap: Hub size was set once in _ready, but on a
	# tall phone the viewport's visible size can settle after that,
	# leaving Hub (and its bar) short of the screen bottom until the
	# first menu tap re-laid things out. Follow the viewport every
	# frame so the bar is flush from the very first frame, not after
	# the first tap. Margin (anchors 0,0,1,1) follows Hub size.
	var _vp = get_viewport_rect().size
	if size != _vp:
		size = _vp
	# Dev42 edge-to-edge + flush bottom: safe_area_margin.gd resets
	# margin_bottom to max(12, safe) on size_changed, which put a gap
	# below the bar on the phone (headless never sees it, window 0).
	# Re-assert 0 every frame, and force NavBar alone to full screen
	# width (upper rows keep their 12px Margin inset).
	if $Margin.get_theme_constant("margin_bottom") != 0:
		$Margin.add_theme_constant_override("margin_bottom", 0)
	var _bar2 = $Margin/MainVBox/NavBar
	var _ml = $Margin.get_theme_constant("margin_left")
	if _bar2.position.x != -float(_ml) or _bar2.size.x != size.x:
		_bar2.position.x = -float(_ml)
		_bar2.size.x = size.x
	# dev46 first-load bar height, part 2 (corrected after headless
	# proof): MarginContainer sizes itself to its child minimum,
	# NOT to Hub, so forcing Margin/MainVBox size to the viewport
	# in _process is undone by the next container sort - Margin
	# reverts to content height (headless: 956 for an 800 viewport).
	# The only way to push the bar to the screen bottom on first
	# load is to grow the content itself: size AFKSpacer to fill
	# the viewport height minus margins and the other Home rows.
	# On the phone the viewport is taller than the content, so the
	# spacer grows by exactly the gap that used to sit below the
	# bar; on Home the top rows do not move, only the AFK area
	# grows. After a menu tap the bar no longer drops, because it
	# was already at the bottom. Headless cannot prove this (its
	# 800px viewport is already shorter than the content minimum),
	# so the phone test is the verdict.
	if _current_view == null and $Margin/MainVBox/TopBar.visible:
		var _main2 = $Margin/MainVBox
		var _other2 := 0.0
		for _n in [$Margin/MainVBox/TopBar, $Margin/MainVBox/StageVBox, $Margin/MainVBox/AFKLabel, $Margin/MainVBox/BestLabel, $Margin/MainVBox/ActionRow, _bar2]:
			if _n.visible:
				_other2 += _n.size.y
		_other2 += float(_main2.get_theme_constant("separation")) * 6.0
		var _target2 = size.y - float($Margin.get_theme_constant("margin_top")) - float($Margin.get_theme_constant("margin_bottom")) - _other2
		var _spacer2 = $Margin/MainVBox/AFKSpacer
		if _target2 > 260.0 and abs(_spacer2.custom_minimum_size.y - _target2) > 1.0:
			_spacer2.custom_minimum_size.y = _target2
	# MainVBox position only (size is set by MarginContainer from
	# content, see above): the old entry-animation tween left it
	# at y=0 instead of the margin position.
	var _mt2 = float($Margin.get_theme_constant("margin_top"))
	if $Margin/MainVBox.position != Vector2(_ml, _mt2):
		$Margin/MainVBox.position = Vector2(_ml, _mt2)
	# View Manager: container fills the area above the nav bar, so a
	# view is clipped at the bar top and never covers the nav.
	if _view_container != null:
		_view_container.position = Vector2.ZERO
		_view_container.size = Vector2(size.x, _bar2.get_global_rect().position.y)
	# Notch vertical follow only: notch is a Hub child (sibling outside
	# NavRow, per Gemini notch batch), so its x is tweened, not forced
	# every frame. Its y follows the bar if layout/safe-area moves it.
	if _nav_notch != null:
		_nav_notch.position.y = $Margin/MainVBox/NavBar.get_global_rect().position.y - 12.0
	if _nav_border_cover != null:
		_nav_border_cover.position.y = $Margin/MainVBox/NavBar.get_global_rect().position.y
	# Re-centre buttons horizontally if slot width changed (e.g. safe-area
	# / layout settle after load) — x only, never y/scale, so it cannot
	# fight the Tween that controls lift/scale, and cannot cut off the
	# leftmost/rightmost icons by leaving them off-centre in their slots.
	for _slot_name in ["SlotStore", "SlotGear", "SlotBattle", "SlotModes", "SlotQuests"]:
		var _slot = $Margin/MainVBox/NavBar/NavVBox/NavRow.get_node(_slot_name)
		var _btn = _slot.get_child(0)
		var _cx = (_slot.size.x - _btn.size.x) / 2.0
		if abs(_btn.position.x - _cx) > 1.0:
			_btn.position.x = _cx
	if _current_view != null:
		return
	t += delta
	# Hero lives in the AFKSpacer, not at a viewport-calculated y.
	# Spacer rect is the real AFK area between stage and AFK ticker,
	# so hero can never overlap Best text or sit below nav again.
	var _sp = $Margin/MainVBox/AFKSpacer.get_global_rect()
	var _cx = _sp.position.x + _sp.size.x / 2.0
	var _cy = _sp.position.y + _sp.size.y / 2.0
	hero.position.x = _cx - 35.0 + sin(t * 0.7) * 80.0
	hero.position.y = _cy - 67.0 + sin(t * 1.3) * 25.0 + sin(t * 3.0) * 6.0
	$AFKDraw.afk_bottom = _sp.position.y + _sp.size.y
	$AFKDraw.afk_top = _sp.position.y
	var afk = $AFKDraw
	$Margin/MainVBox/AFKLabel.text = "AFK collected this session: %d coins (show-only)" % afk.afk_coins
	$Margin/MainVBox/ActionRow/BattleButton.modulate = Color(1, 1, 1) if sin(t * 3.0) > 0 else Color(0.9, 1, 0.95)

func _update_stage_label() -> void:
	var locked := stage > 1
	$Margin/MainVBox/StageVBox/StageLabel.text = "STAGE %d — %s" % [stage, "First Flight" if stage == 1 else "Locked" if locked else "Next Stage"]
	$Margin/MainVBox/StageVBox/StageRow/StageLabelButton.text = "%s STAGE %d" % [mode.to_upper(), stage]

func _set_mode(m: String) -> void:
	if m == "Elite" and not elite_unlocked:
		$Margin/MainVBox/StageVBox/StageLabel.text = "ELITE — LOCKED until Level 10"
		return
	mode = m
	_update_stage_label()

func _change_stage(d: int) -> void:
	stage = clamp(stage + d, 1, 5)
	_update_stage_label()

func _hide_panels() -> void:
	$SelectPanel.visible = false
	$PatrolPanel.visible = false
	$InfoPanel.visible = false
	$SidePanel.visible = false

func _show_panel(p: Panel) -> void:
	_hide_panels()
	p.visible = true
	MenuAnim.panel_pop(p)

func _side_popup(title: String, body: String) -> void:
	$SidePanel/SideTitle.text = title
	$SidePanel/SideLabel.text = body
	_show_panel($SidePanel)

func _fade_in_overlay() -> void:
	var overlay = ColorRect.new()
	overlay.color = Color(0, 0, 0, 1)
	overlay.size = size
	add_child(overlay)
	var tw := create_tween()
	tw.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_property(overlay, "modulate:a", 0.0, 0.25)
	tw.tween_callback(func(): overlay.queue_free())
