class_name MenuStyle
extends RefCounted
# Menus polish: real box outlines + icons, not plain text buttons.
# StyleBoxFlat gives a raised panel/box: dark fill, cyan/purple border,
# rounded corners, small shadow offset. Icons are simple PNGs in icons/.
static func icons_only(root: Node) -> void:
	_icons_recursive(root)

static func _icons_recursive(node: Node) -> void:
	if node is Button:
		var b: Button = node
		var t: String = b.text
		var icon := ""
		if "Gear" in t: icon = "gear"
		elif "Home" in t: icon = "home"
		elif "Modes" in t: icon = "modes"
		elif "Quests" in t: icon = "quests"
		elif "Store" in t: icon = "store"
		elif "BATTLE" in t: icon = "battle"
		elif "Event" in t: icon = "event"
		elif "Promo" in t: icon = "promo"
		elif "Starter" in t: icon = "starter"
		elif "Daily" in t: icon = "daily"
		elif "Gifts" in t: icon = "gifts"
		elif "Ranks" in t: icon = "ranks"
		elif "Chest" in t: icon = "chest"
		elif "Patrol" in t: icon = "patrol"
		if icon != "":
			var tex := load("res://icons/%s.png" % icon)
			if tex: b.icon = tex
	for child in node.get_children():
		_icons_recursive(child)

static func style_all(root: Node) -> void:
	_style_recursive(root)

static func _box(border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = Color(0.08, 0.11, 0.22, 1)
	s.border_width_left = 2
	s.border_width_right = 2
	s.border_width_top = 2
	s.border_width_bottom = 2
	s.border_color = border
	s.corner_radius_top_left = 12
	s.corner_radius_top_right = 12
	s.corner_radius_bottom_left = 12
	s.corner_radius_bottom_right = 12
	s.shadow_size = 4
	s.shadow_color = Color(0, 0, 0, 0.5)
	s.shadow_offset = Vector2(0, 3)
	return s

static func _style_recursive(node: Node) -> void:
	if node is Button:
		var b: Button = node
		b.add_theme_stylebox_override("normal", _box(Color(0.2, 0.85, 1.0)))
		b.add_theme_stylebox_override("hover", _box(Color(0.7, 0.5, 1.0)))
		b.add_theme_stylebox_override("pressed", _box(Color(1, 0.8, 0.3)))
		var t: String = b.text
		var icon := ""
		if "Gear" in t: icon = "gear"
		elif "Home" in t: icon = "home"
		elif "Modes" in t: icon = "modes"
		elif "Quests" in t: icon = "quests"
		elif "Store" in t: icon = "store"
		elif "BATTLE" in t: icon = "battle"
		elif "Event" in t: icon = "event"
		elif "Promo" in t: icon = "promo"
		elif "Starter" in t: icon = "starter"
		elif "Daily" in t: icon = "daily"
		elif "Gifts" in t: icon = "gifts"
		elif "Ranks" in t: icon = "ranks"
		elif "Chest" in t: icon = "chest"
		elif "Patrol" in t: icon = "patrol"
		elif "Standard" in t: icon = "modes"
		elif "Horde" in t: icon = "modes"
		if icon != "":
			var tex := load("res://icons/%s.png" % icon)
			if tex: b.icon = tex
	if node is Panel:
		var p: Panel = node
		p.add_theme_stylebox_override("panel", _box(Color(0.7, 0.5, 1.0)))
	for child in node.get_children():
		_style_recursive(child)
