# Skybound Defender — source package for Rudy

This is the full Godot project for the game you have been playtesting.
Latest version in this package: 1.0-dev53 (versionCode 53).
Package name: com.skybound.defender. Main scene: hub.tscn (the Home screen).

## What you need to open it

- Godot 4.3 stable, on a PC. That is the exact version this project was built with.
- Open Godot, choose Import, and pick the project.godot file in this folder.
- Let it finish importing (it takes a minute the first time), then press Play.
  You will see the Home screen on your PC, and you can click the bottom tabs
  with a mouse. Touch/drag in battle works with a mouse too.

## Where the notch lives

The bottom bar notch you have been working on is in two places:

- Code: hub.gd
  - _animate_nav_in() — creates the notch when Home first loads.
  - _on_nav_tap() — swaps the notch when you tap a tab.
  - Search hub.gd for "notch" and you will find both spots.
- Pictures: icons/notch_middle.png, icons/notch_left.png, icons/notch_right.png
  - Middle = normal notch. Left = Store edge. Right = Quests edge.
  - These are drawn at 4x size (368 pixels wide) and the game shrinks them
    down to 92 pixels wide on screen, so they stay sharp.
  - If you redraw one, keep the same file name and size, and keep the
    transparent background. The game will pick it up on import.

Other useful files:
- battle.gd / battle.tscn — the battle screen.
- gear.gd, modes.gd, quests.gd, store.gd — the four menu screens.
- soldier_body.png — the current soldier sprite.
- icons/ — all the bottom bar icons, in lit and dull versions.
- export_presets.cfg — the Android export settings. Do not change the
  version code to a lower number; the next build must be 54 or higher.

## How sending work back works

Yes, exactly like you said: you just send the files back here.

- Send back only the files you changed, if that is easier, or the whole
  folder again — either way works.
- Luna will drop your files into the same project, re-import, test that
  it still loads and that the notch still swaps on Store/Gear/Quests,
  and then rebuild the APK with the same signing key as all the other
  builds. That way the new APK installs right over the one on your phone,
  no uninstall needed.
- If you build an APK yourself on your own PC, Godot will sign it with
  your own debug key, which is different from Luna's. That APK will NOT
  install over the current one — your phone will ask you to uninstall
  first, which also wipes the saved best score and coins (that save is
  only best score, best kills and coins, nothing else). And after that,
  Luna's builds will not install over yours either, until you send the
  source back and Luna rebuilds it. So for testing, the cleanest loop is:
  you edit, you send the changed files back, Luna rebuilds and sends one APK.

## Current state, in plain words

- Home, bottom bar, and all four menus open and the bar stays on screen.
- Battle works with relative drag, manual fire while dragging, and
  auto-aim when your finger is lifted.
- The notch is the one open problem: code versions and the drawn-image
  version in dev53 both looked right in testing but did not blend the
  way you want on your phone at the Store and Quests edges. That is the
  part you are taking a look at now.
- Everything else in the game is still test-only: no real purchases,
  no real ads, coins and packs are show-only.
