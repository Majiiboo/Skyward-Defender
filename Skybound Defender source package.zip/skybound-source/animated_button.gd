extends Button
# Gemini Part 2, adapted: Tween scale, not AnimationPlayer per button.
# Scaling UP on hover/enter is safe (hit area grows). Bounce on pressed
# happens AFTER press is confirmed, never on button_down, so it cannot
# cancel the press like the old dev20 scale-on-down bug did.
var tween: Tween
func _ready() -> void:
	pivot_offset = size / 2
	pressed.connect(_on_button_pressed)
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)
func _on_mouse_entered() -> void:
	_animate_scale(Vector2(1.04, 1.04), 0.1)
func _on_mouse_exited() -> void:
	_animate_scale(Vector2(1.0, 1.0), 0.1)
func _on_button_pressed() -> void:
	var press_tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	press_tween.tween_property(self, "scale", Vector2(0.95, 0.95), 0.05)
	press_tween.tween_property(self, "scale", Vector2(1.0, 1.0), 0.1)
func _animate_scale(target_scale: Vector2, duration: float) -> void:
	if tween and tween.is_running():
		tween.kill()
	tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tween.tween_property(self, "scale", target_scale, duration)
