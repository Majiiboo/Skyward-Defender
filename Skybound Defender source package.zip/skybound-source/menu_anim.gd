class_name MenuAnim
extends RefCounted
# Shared menu animation, Menus 0.5: pop-out buttons, not flat.
# Call MenuAnim.pop_buttons(self) in a scene's _ready.
# On press: button scales down to 0.93 and drops 2px (physical press).
# On release: springs back to 1.0. Pivot is centre, so it pops in place.
static func pop_buttons(root: Node) -> void:
	_pop_recursive(root)

static func _pop_recursive(node: Node) -> void:
	if node is Button:
		var b: Button = node
		b.pivot_offset = b.size / 2.0
		# Gemini animated_button: hover 1.04, bounce on pressed AFTER
		# press is confirmed (0.95 -> 1.0, TRANS_SINE, EASE_OUT).
		# Never scale on button_down — that shrank hit area and killed presses.
		b.mouse_entered.connect(func(): _scale_to(b, Vector2(1.04, 1.04), 0.1))
		b.mouse_exited.connect(func(): _scale_to(b, Vector2(1.0, 1.0), 0.1))
		b.pressed.connect(func(): _pulse(b))
	for child in node.get_children():
		_pop_recursive(child)

static func _scale_to(b: Button, target: Vector2, dur: float) -> void:
	var tw := b.create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_property(b, "scale", target, dur)

static func _pulse(b: Button) -> void:
	var tw := b.create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_property(b, "scale", Vector2(0.95, 0.95), 0.05)
	tw.tween_property(b, "scale", Vector2(1.0, 1.0), 0.1)

static func panel_pop(panel: Control) -> void:
	panel.scale = Vector2(0.9, 0.9)
	panel.pivot_offset = panel.size / 2.0
	var tw := panel.create_tween()
	tw.tween_property(panel, "scale", Vector2(1.0, 1.0), 0.25)
